import os
from os import system, name
import httpx
import undetected_chromedriver as webdriver
from httpx import AsyncClient, Headers
import os, threading, requests, cloudscraper, datetime, time, socket, ssl, random, socket
import socket
import getpass
import sys
from urllib.parse import urlparse
from requests.cookies import RequestsCookieJar
import undetected_chromedriver as webdriver
from sys import stdout
from colorama import Fore, init
from sys import argv
from threading import Thread
os.system("git pull")
os.system("clear")
red    = "\033[31m"
blue   = "\033[34m"
bold   = "\033[1m"
reset  = "\033[0m"
green  = "\033[32m"
yellow = "\033[33m"
colors = [
    "\033[38;5;226m",
    "\033[38;5;227m",
    "\033[38;5;229m",
    "\033[38;5;230m",
    "\033[38;5;190m",
    "\033[38;5;191m",
    "\033[38;5;220m",
    "\033[38;5;221m",
    "\033[38;5;142m",
    "\033[38;5;214m",
]


print("")
print("")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"╔═════════╩═══════════════════════════════╩═════════╗\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 0 ]"+Fore.LIGHTWHITE_EX+" Install Command                             ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 1 ]"+Fore.LIGHTWHITE_EX+" DDOS Attacker URL [ FREE ]                  ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 2 ]"+Fore.LIGHTWHITE_EX+" DDOS Attacker URL [ PREM ]                  ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 3 ]"+Fore.LIGHTWHITE_EX+" DDOS LENGKAP [ PREM ]                       ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 4 ]"+Fore.LIGHTWHITE_EX+" CREATE DEFACE  [ FREE ]                     ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 5 ]"+Fore.LIGHTWHITE_EX+" DEFACE WEBSITE [ FREE ]                     ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 6 ]"+Fore.LIGHTWHITE_EX+" CAMERA HACKER [ FREE ]                      ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m[ 7 ]"+Fore.LIGHTWHITE_EX+" DDOS JAVA     [ FREE ]                      ║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"╠═══════════════════════════════════════════════════╣\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m• "+Fore.LIGHTYELLOW_EX+"TELEGRAM    "+Fore.LIGHTWHITE_EX+"|"+Fore.LIGHTYELLOW_EX+" t.me/aileenxmods                  "+Fore.LIGHTWHITE_EX+"║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m• "+Fore.LIGHTYELLOW_EX+"WHATSAPP    "+Fore.LIGHTWHITE_EX+"|"+Fore.LIGHTYELLOW_EX+" wa.me/6285764113580               "+Fore.LIGHTWHITE_EX+"║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"║ \x1b[38;2;255;20;147m• "+Fore.LIGHTYELLOW_EX+"GITHUB      "+Fore.LIGHTWHITE_EX+"|"+Fore.LIGHTYELLOW_EX+" github.com/                       "+Fore.LIGHTWHITE_EX+"║\n")
stdout.write("             "+Fore.LIGHTWHITE_EX            +"╚═══════════════════════════════════════════════════╝\n")
stdout.write("\n")
    
c = input("\033[31m Root\033[0m@\033[34mLocalHost\033[32m: ")

if c == "0":
    os.system("python3 .setup.py")
if c == "1":
    os.system("python3 .ddosjava.py")
if c == "2":
    os.system("python3 .a.py")
if c == "3":
    os.system("python3 .ddos.py")
if c == "4":
    os.system("python2 .c.py")
if c == "5":
    os.system("python3 .wd.py")
if c == "6":
    os.system("cd .CamHacker && bash ch.sh")
if c == "7":
    os.system("java .ddosattack.java")
    print(" INSTALL JAVA pkg install java ")
else:	
    print("           [ Perintah Tidak Di Temukan ]")
    os.system("python start.py")
print("Done")
